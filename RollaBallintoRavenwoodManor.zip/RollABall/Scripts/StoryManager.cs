using UnityEngine;
using UnityEngine.UI;

public class StoryManager : MonoBehaviour
{
    [System.Serializable]
    public class StoryNode
    {
        [TextArea(3, 10)]
        public string dialogue;
        public string option1Text;
        public int option1NextIndex;
        public string option2Text;
        public int option2NextIndex;
    }

    public Text dialogueText;
    public Button option1Button;
    public Button option2Button;
    public StoryNode[] storyNodes;

    private int currentNodeIndex = 0;

    void Start()
    {
        DisplayNode(currentNodeIndex);
    }

    void DisplayNode(int index)
    {
        currentNodeIndex = index;
        StoryNode node = storyNodes[index];

        dialogueText.text = node.dialogue;
        option1Button.GetComponentInChildren<Text>().text = node.option1Text;
        option2Button.GetComponentInChildren<Text>().text = node.option2Text;

        option1Button.onClick.RemoveAllListeners();
        option2Button.onClick.RemoveAllListeners();

        option1Button.onClick.AddListener(() => DisplayNode(node.option1NextIndex));
        option2Button.onClick.AddListener(() => DisplayNode(node.option2NextIndex));
    }
}